# FOOTBALL PROFIT AI — backend inicial

## O que inclui
- API FastAPI com `/api/health`
- Cálculo Poisson em `/api/predictions/analyze`
- Jogos reais em `/api/fixtures` quando a chave API-Football estiver configurada
- Pesquisa de equipas e ligas
- Configuração inicial para Render

## 1. Preparar a API de futebol
Cria uma conta em API-Sports / API-Football e obtém uma chave. Guarda-a como variável de ambiente `API_FOOTBALL_KEY`. Nunca coloques a chave no HTML/JavaScript público nem a partilhes em mensagens.

## 2. Executar localmente
Requer Python 3.10+.

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
```

Copia `.env.example` para `.env` e define `API_FOOTBALL_KEY`. Para carregar o `.env` localmente, instala `python-dotenv` ou exporta a variável no terminal.

```bash
uvicorn app.main:app --reload
```

Abre `http://127.0.0.1:8000/docs` para testar e `http://127.0.0.1:8000/api/health` para verificar.

## 3. Publicar no Render
1. Envia esta pasta para um repositório GitHub.
2. No Render escolhe **New > Blueprint** e liga o repositório.
3. O Render lê `render.yaml`.
4. Em Environment adiciona `API_FOOTBALL_KEY` com a chave do fornecedor.
5. Depois do deploy, confirma `/api/health`.

## 4. Ligar o HTML existente
O HTML atual usa caminhos relativos (`/api/...`). Em alojamento separado, altera o JavaScript para usar o endereço do backend, por exemplo:

```js
const API_BASE = "https://TEU-SERVICO.onrender.com";
async function api(path, opts) {
  const r = await fetch(API_BASE + path, opts);
  const data = await r.json();
  if (!r.ok) throw new Error(data.detail || "Erro de API");
  return data;
}
```

Substitui `TEU-SERVICO` pelo domínio real que o Render atribuir. Não publiques o site antes de substituir esse valor.

## Limitações desta primeira versão
- O endpoint de jogos consulta fixtures reais do fornecedor quando existe chave.
- A análise Poisson usa os xG inseridos pelo utilizador; ainda não estima xG automaticamente a partir de histórico.
- O histórico do HTML original ainda não está implementado em base de dados nesta versão.
- Antes de uso público alargado, adicionar autenticação, limites de pedidos, cache, monitorização, testes e política de privacidade.
- Confirma os limites, cobertura, preços e permissões comerciais do plano API contratado.


## 5. Publicar a página
A pasta `frontend` contém o HTML original adaptado para chamar o backend remoto. Publica `frontend/index.html` num alojamento estático (por exemplo, GitHub Pages, Netlify ou Cloudflare Pages). Antes de publicar, substitui `https://TEU-BACKEND.onrender.com` no ficheiro pelo URL real do serviço Render.
