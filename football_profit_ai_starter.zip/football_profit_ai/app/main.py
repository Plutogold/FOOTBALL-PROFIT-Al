import os
import sqlite3
from datetime import date, datetime, timezone
from typing import Optional

import httpx
from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

app = FastAPI(title="FOOTBALL PROFIT AI API", version="1.0.0")

# Public website: restrict CORS with FRONTEND_ORIGIN in production.
origins = os.getenv("FRONTEND_ORIGIN", "*").split(",")
app.add_middleware(
    CORSMiddleware,
    allow_origins=[x.strip() for x in origins],
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

API_BASE = "https://v3.football.api-sports.io"
API_KEY = os.getenv("API_FOOTBALL_KEY", "")
DEMO_MODE = not bool(API_KEY)
DB_PATH = os.getenv("DB_PATH", "football_profit_ai.db")

def init_db():
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute("""CREATE TABLE IF NOT EXISTS analyses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            home_team TEXT NOT NULL, away_team TEXT NOT NULL,
            competition TEXT NOT NULL, created_at TEXT NOT NULL
        )""")

init_db()

class AnalyzeRequest(BaseModel):
    home_team: str = Field(min_length=1, max_length=80)
    away_team: str = Field(min_length=1, max_length=80)
    home_xg: float = Field(gt=0.01, le=5)
    away_xg: float = Field(gt=0.01, le=5)
    competition: str = Field(default="Demonstração", max_length=100)

def poisson(lam: float, k: int) -> float:
    import math
    return math.exp(-lam) * (lam ** k) / math.factorial(k)

def probabilities(home_xg: float, away_xg: float):
    max_goals = 10
    scores = []
    home_win = draw = away_win = over25 = btts = 0.0
    for h in range(max_goals + 1):
        for a in range(max_goals + 1):
            p = poisson(home_xg, h) * poisson(away_xg, a)
            scores.append({"score": f"{h}-{a}", "probability": p})
            if h > a: home_win += p
            elif h == a: draw += p
            else: away_win += p
            if h + a >= 3: over25 += p
            if h > 0 and a > 0: btts += p
    total = home_win + draw + away_win
    return {
        "home_win": home_win / total,
        "draw": draw / total,
        "away_win": away_win / total,
        "over_2_5": over25 / total,
        "btts_yes": btts / total,
    }, sorted(scores, key=lambda x: x["probability"], reverse=True)[:5]

@app.get("/api/health")
async def health():
    return {"status": "ok", "provider_mode": "demo" if DEMO_MODE else "api"}

@app.post("/api/predictions/analyze")
async def analyze(req: AnalyzeRequest):
    probs, top_scores = probabilities(req.home_xg, req.away_xg)
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute(
            "INSERT INTO analyses(home_team, away_team, competition, created_at) VALUES (?, ?, ?, ?)",
            (req.home_team, req.away_team, req.competition, datetime.now(timezone.utc).isoformat())
        )
    return {
        "home_team": req.home_team,
        "away_team": req.away_team,
        "competition": req.competition,
        "probabilities": probs,
        "top_scores": top_scores,
        "warning": "Estimativa matemática baseada nos xG introduzidos; não garante resultados."
    }

async def football_api(path: str, params: dict):
    if not API_KEY:
        raise HTTPException(status_code=503, detail="API_FOOTBALL_KEY não configurada. Adiciona a chave nas variáveis de ambiente.")
    headers = {"x-apisports-key": API_KEY}
    async with httpx.AsyncClient(timeout=20) as client:
        try:
            response = await client.get(f"{API_BASE}/{path}", headers=headers, params=params)
            response.raise_for_status()
            payload = response.json()
        except httpx.HTTPError as exc:
            raise HTTPException(status_code=502, detail=f"Erro ao contactar fornecedor de futebol: {exc}")
    if payload.get("errors"):
        raise HTTPException(status_code=502, detail=str(payload["errors"]))
    return payload

@app.get("/api/fixtures")
async def fixtures(day: date = Query(default_factory=date.today)):
    if DEMO_MODE:
        return {"response": [], "notice": "Modo demonstração: configura API_FOOTBALL_KEY para obter jogos reais."}
    return await football_api("fixtures", {"date": day.isoformat(), "timezone": "Europe/Lisbon"})

@app.get("/api/teams/search")
async def search_teams(name: str = Query(min_length=2, max_length=80), country: Optional[str] = None):
    params = {"search": name}
    if country:
        params["country"] = country
    return await football_api("teams", params)

@app.get("/api/leagues")
async def leagues(season: int, country: Optional[str] = None):
    params = {"season": season}
    if country:
        params["country"] = country
    return await football_api("leagues", params)

@app.get("/api/predictions/history")
async def history():
    with sqlite3.connect(DB_PATH) as conn:
        conn.row_factory = sqlite3.Row
        rows = conn.execute("SELECT home_team, away_team, competition, created_at FROM analyses ORDER BY id DESC LIMIT 100").fetchall()
    return [dict(row) for row in rows]
